#define equation1 "(2+2)(3-2) + 1"
